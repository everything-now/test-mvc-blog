<div id="respond">
<h3 id="reply-title"><?php echo e(Auth::user()->name); ?>, прокоментуйте</h3>
	<?php echo Form::open(array(
						'method'=>'POST',
						'accept-charset'=>'UTF-8',
						'id'=>'commentform',
						)); ?>

<?php echo Form::textarea('content','',array('id'=>'','class'=>'text-area required','cols'=>'')); ?>

<input type="hidden" name="user" value="<?php echo e(Auth::user()->name); ?>"/><br>
<p class="form-submit"><?php echo Form::submit('Відправити', array('id'=>'submit')); ?></p>
<?php echo Form::close(); ?>


<?php if(Session::has('message')): ?>
<?php echo e(Session::get('message')); ?> 
<?php endif; ?>
</div>
