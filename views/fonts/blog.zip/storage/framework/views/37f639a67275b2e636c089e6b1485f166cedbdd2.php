<?php $__env->startSection('content'); ?>

<div class="content box">
    <h1 class="title"> Книга замовлень </h1>
<form method="POST" action="/bookorders" class="forms">
 <fieldset>
            <ol>
        <li class="form-row text-input-row"><label>Назва фільму українською</label><input class="text-input required" name="title" type="text"></li> 

  <li class="form-row text-input-row"><select class="asd js-data-example-ajax" name="from_imdb">
 <option value="title" selected="selected">Оригінальна назва</option>
</select></li> 
<li class="form-row text-area-row"><label>Побажання</label><?php echo Form::textarea('wish','',array('id'=>'','class'=>'text-area required', 'rows'=>'2')); ?></li>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<input class="btn-submit" type="submit" value="Замовити">
        </ol>
        </fieldset>
</form>
<?php if(Session::has('message')): ?>
<?php echo e(Session::get('message')); ?> 
<?php endif; ?>
<br>
<table border="1" class="table table-striped">
<thead>
<tr>
    <th>Статус</th>
    <th>Зображення</th>
    <th>Назва українською</th>
    <th>Оригінальна назва</th>
    <th>Рік</th>
    <th>Замовив</th>
    <th>Дата замовлення</th>

  </tr>
  </thead>
   <tbody>
 <?php foreach($bookorders as $bookorder): ?>
	
    	<tr>

    	<td> <?php echo e($bookorder->status); ?>  </td> 
    	<td> <img width='54' height='80' src="<?php echo e($bookorder->image); ?>"></td> 
    	<td>  <?php echo e($bookorder->title); ?> </td> 
    	<td>  <?php echo e($bookorder->title_original); ?> </td> 
    	<td>  <?php echo e($bookorder->year); ?> </td> 
    	<td align="center">  <?php echo e($bookorder->orderer); ?> </td> 
    	<td align="center">  <?php echo e($bookorder->created_at); ?> </td> 

    	</tr>

<?php endforeach; ?>


 </tbody>
</table>

</div>
<div class="clear"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>