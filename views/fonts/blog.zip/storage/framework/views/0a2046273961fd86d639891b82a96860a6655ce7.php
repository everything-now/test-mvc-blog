<?php $__env->startSection('content'); ?>

<div class="content box">

    <h1 class="title">Редагувати фільм <?php echo e($post->title); ?></b></h1>
<div class="form-container">
    <?php echo Form::model($post, array(
                        'action'=> ['PostController@update', $post->id],
                        'method'=>'PATCH',
                        'accept-charset'=>'UTF-8',
                        'class'=>'forms',
                        'files'=>true,
                        )); ?> 
        <fieldset>
            <ol>
                <li class="form-row text-input-row"><label>Назва</label><?php echo Form::text('title',null,array('id'=>'','class'=>'text-input required')); ?></li> 
                <li class="form-row text-area-row"><label>Категорія</label> <?php echo Form::select('id_category', $category); ?></li> 
                <li class="form-row text-area-row"><label>Опис</label><?php echo Form::textarea('content',null,array('id'=>'','class'=>'text-area required')); ?></li> 
                <li class="form-row text-input-row"><label>Відео</label><?php echo Form::text('video',null,array('id'=>'','class'=>'text-input required')); ?> </li> 
                <li class="form-row text-input-row"><label>Зображення</label><?php echo Form::file('image', null); ?> </li> 
                <li class="button-row"><?php echo Form::submit('Редагувати', array('class' => 'btn-submit')); ?>  </li>
            </ol>
        </fieldset>
    <?php echo Form::close(); ?>

</div>


</div>
<div class="clear"></div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>