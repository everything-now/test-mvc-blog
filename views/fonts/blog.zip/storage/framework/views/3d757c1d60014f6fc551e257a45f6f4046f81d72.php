<?php $__env->startSection('content'); ?>

<div class="content box">

    <h1 class="title">Додати фільм</h1>
<div class="form-container">
    <?php echo Form::open(array(
                        'url'=> action('PostController@store'),
                        'method'=>'POST',
                        'accept-charset'=>'UTF-8',
                        'class'=>'forms',
                        'files'=>true,
                        )); ?> 
        <fieldset>
            <ol>
                <li class="form-row text-input-row"><label>Назва</label><?php echo Form::text('title','',array('id'=>'','class'=>'text-input required')); ?></li> 
                <li class="form-row text-area-row"><label>Категорія</label> <?php echo Form::select('id_category', $category, array('id'=>'soflow')); ?></li> 
                <li class="form-row text-area-row"><label>Опис</label><?php echo Form::textarea('content','',array('id'=>'','class'=>'text-area required')); ?></li> 
                <li class="form-row text-input-row"><label>Відео</label><?php echo Form::text('video','',array('id'=>'','class'=>'text-input required')); ?> </li> 
                <li class="form-row text-input-row"><label>Зображення</label><?php echo Form::file('image', null); ?> </li> 
                <li class="button-row"><?php echo Form::submit('Додати', array('class' => 'btn-submit')); ?>  </li>
            </ol>
        </fieldset>
    <?php echo Form::close(); ?>

</div>

</div>
<div class="clear"></div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>