<?php $__env->startSection('content'); ?>

<div class="box">

    <h1 class="title"><?php echo e($post->title); ?> </h1>       
    
    <div class="one-third">
      
      <div class="outer none"><span class="inset"><img width="290 px" src="<?php echo e($post->image); ?>"/></span></div>
      Додано: <?php echo e($post->created_at); ?><br> <!-- Оновлено: <?php echo e($post->updated_at); ?> --><br>

      Рейтинг IMDB:<b> <?php echo e($rating->movie['imdbRating']); ?>/10</b><br>
      Всього голосів: <?php echo e($rating->movie['imdbVotes']); ?><br><br>

      Рейтинг за версією сайту
      <div id="rating">
        <input type="hidden" name="val" value="<?php echo e($votes); ?>">
        <input type="hidden" name="votes" value="<?php echo e($count_votes); ?>">
      </div>
      <?php if(Auth::guest() == false): ?>
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id); ?>">
      <input type="hidden" name="id_post" value="<?php echo e($post->id); ?>">
      <?php endif; ?>
    </div>
    <script type="text/javascript">
    $('#rating').rating({
      fx: 'full',
      image: '/images/votes/stars.png',
      loader: '/images/votes/ajax-loader.gif',
      url: '<?php echo e(URL::action('VoteController@store')); ?>',
      <?php if(Auth::guest() || Auth::user()->id == $validate): ?> readOnly: true, <?php endif; ?>
       callback: function(responce){
           this.vote_success.fadeOut(2000);
       }
        });
    </script>

    <div class="two-third last">
    <?php if (Gate::check('create')): ?> <div align="right"><a href="<?php echo e($post->id); ?>/edit">Редагувати</a></div> <?php endif; ?>
      <h4>Про фільм</h4>
        <?php echo e($post->content); ?>


      <h4>Відео</h4>
        <?php echo $post->video; ?>   
    <br><br>

    <div id="comments">
              
      <h3 id="comments-title"> <?php if($count_comments == 0): ?> Ще ніхто не залишив відгук <?php else: ?> Всього коментарів: <?php echo e($count_comments); ?> <?php endif; ?></h3>
      <?php foreach($comments as $comment): ?>
          <ol id="singlecomments" class="commentlist">
          <li class="comment">
        <div class="comment">
          <div class="comment-author vcard user frame">
            <img alt="" src='/images/movie.jpg' class='avatar avatar-70 photo' height='70' width='70' />
          </div>
          <div class="message">

            <div class="info">
              <h2><?php echo e($comment->user); ?></h2>
              <span class="meta"> <?php echo e($comment->created_at); ?></span>
            </div>
            <div class="comment-body ">
              <p><?php echo e($comment->content); ?></p>
            </div>
            <span class="edit-link"></span>
          </div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
      </li></ol>
      <?php endforeach; ?>
    </div>

    <div class="clear"></div>
          <div id="comment-form" class="comment-form">
          <?php if(Auth::guest()): ?>
              Щоб залишити коментар <a href="<?php echo e(url('/login')); ?>">авторизуйтесь</a> або <a href="<?php echo e(url('/register')); ?>">пройдіть реєстрацію</a>               
          <?php else: ?>
          <?php echo $__env->make('comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endif; ?>
          </div>
</div>

</div>

<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>