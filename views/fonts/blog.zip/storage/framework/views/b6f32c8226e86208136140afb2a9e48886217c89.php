<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,400italic,300italic,300,700,700italic|Open+Sans+Condensed:300,700' rel="stylesheet" type='text/css'>

    <link rel="stylesheet" type="text/css" media="all" href="/css/style.css" />
    <link rel="stylesheet" type="text/css" href="/css/media-queries.css" />
    <link href="/css/s2-docs.css" rel="stylesheet" />
    <!-- Styles -->

    <link href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css" rel="stylesheet" />


   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script type="text/javascript" src="/js/jquery.rating.js"></script>
    <script type="text/javascript" src="/js/ddsmoothmenu.js"></script>
    <script type="text/javascript" src="/js/selectnav.js"></script>
    <script type="text/javascript" src="/js/jquery.masonry.min.js"></script>
    <script type="text/javascript" src="/js/jquery.fitvids.js"></script>
    <script type="text/javascript" src="/js/jquery.backstretch.min.js"></script>
    <script type="text/javascript" src="/js/jquery.dcflickr.1.0.js"></script>
    <script type="text/javascript" src="/js/twitter.min.js"></script>
    <script type="text/javascript">
    $.backstretch("/images/bg/9.jpg");
</script>
</head>
<body>
<div class="scanlines"></div>

<!-- Begin Header -->
<div class="header-wrapper opacity">
    <div class="header">
        <!-- Begin Logo -->
        <div class="logo">
            <a href="/">
                <img width="130 px" src="/images/logo.png" alt="" />
            </a>
        </div>
        <!-- End Logo -->
        <!-- Begin Menu -->
        <div id="menu-wrapper">
            <div id="menu" class="menu">
                <ul id="tiny">
                    <li class="active"><a href="/">Головна</a></li>
                    <li><a href="#">Категорії</a>
                        <ul>
                            <li><a href="<?php echo e(url('/category/1')); ?>">Фільми</a></li>
                            <li><a href="<?php echo e(url('/category/2')); ?>">Серіали</a></li>
                            <li><a href="<?php echo e(url('/category/3')); ?>">Мультфільми</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('/bookorders')); ?>">Книга замовлень</a></li>
                    <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('login')); ?>">Увійти</a></li>
                    <li><a href="<?php echo e(url('register')); ?>">Зареєструватись</a></li>
                    <?php else: ?>
                     <li><a href="#"><?php echo e(Auth::user()->name); ?></a>
                        <ul>
                            <li><a href="<?php echo e(url('/logout')); ?>">Вийти</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if (Gate::check('create')): ?>
                    <li><a href="<?php echo e(url('/add_post')); ?>">Додати</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="clear"></div>
        <!-- End Menu -->
    </div>
</div>
<!-- End Header -->
<div class="asdfasfas">
<div class="wrapper">
   
<?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Begin Footer -->

<div class="site-generator-wrapper">
    <div class="site-generator">by Vadym 2016. All rights reserved.</div>
</div>
</div>
<!-- End Footer --> 


    <!-- JavaScripts -->

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="/js/select2.min.js"></script>
    <script src="/js/ui.js"></script>
    <script type="text/javascript" src="/js/scripts.js"></script>
</body>

</html>
