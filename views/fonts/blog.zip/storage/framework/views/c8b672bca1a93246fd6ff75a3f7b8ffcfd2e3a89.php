<?php $__env->startSection('content'); ?>

<div class="intro"><?php if(isset($category)): ?> <?php echo e($category); ?> <?php else: ?> Усі фільми <?php endif; ?></div>
<div class="blog-wrap">

    <div class="blog-grid">


		<?php foreach($allposts as $post): ?>
        <div class="post format-image box"> 
            <div class="frame"> 
                <a href="/allposts/<?php echo e($post->id); ?>">
                    <img class="center" src="<?php echo e($post->image); ?>" alt="" />
                </a>
            </div>
            <h2 class="title"><a href="/allposts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h2>
            <p><?php echo e($post->content); ?></p>
            <div class="details">
                <span class="icon-video"><?php echo e($post->created_at); ?></span>
                <span class="likes"><a href="#" class="likeThis">44</a></span>
                <span class="comments"><a href="#">3</a></span>
            </div>
        </div>
        <?php endforeach; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>