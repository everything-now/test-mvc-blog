<div id="respond">
<h3 id="reply-title">{{ Auth::user()->name }}, прокоментуйте</h3>
	{!! Form::open(array(
						'method'=>'POST',
						'accept-charset'=>'UTF-8',
						'id'=>'commentform',
						)) !!}
{!! Form::textarea('content','',array('id'=>'','class'=>'text-area required','cols'=>'')) !!}
<input type="hidden" name="user" value="{{ Auth::user()->name }}"/><br>
<p class="form-submit">{!! Form::submit('Відправити', array('id'=>'submit')) !!}</p>
{!! Form::close() !!}

@if(Session::has('message'))
{{Session::get('message') }} 
@endif
</div>
