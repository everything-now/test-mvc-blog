@extends('layouts.app')

@section('content')

<div class="intro">@if(isset($category)) {{$category}} @else Усі фільми @endif</div>
<div class="blog-wrap">

    <div class="blog-grid">


		@foreach ($allposts as $post)
        <div class="post format-image box"> 
            <div class="frame"> 
                <a href="/allposts/{{$post->id}}">
                    <img class="center" src="{{$post->image}}" alt="" />
                </a>
            </div>
            <h2 class="title"><a href="/allposts/{{$post->id}}">{{ $post->title }}</a></h2>
            <p>{{ $post->content }}</p>
            <div class="details">
                <span class="icon-video">{{ $post->created_at }}</span>
                <span class="likes"><a href="#" class="likeThis">44</a></span>
                <span class="comments"><a href="#">3</a></span>
            </div>
        </div>
        @endforeach

    </div>

</div>

@endsection
