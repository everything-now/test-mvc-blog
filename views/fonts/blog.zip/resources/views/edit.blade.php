@extends('layouts.app')

@section('content')

<div class="content box">

    <h1 class="title">Редагувати фільм {{ $post->title }}</b></h1>
<div class="form-container">
    {!! Form::model($post, array(
                        'action'=> ['PostController@update', $post->id],
                        'method'=>'PATCH',
                        'accept-charset'=>'UTF-8',
                        'class'=>'forms',
                        'files'=>true,
                        )) !!} 
        <fieldset>
            <ol>
                <li class="form-row text-input-row"><label>Назва</label>{!! Form::text('title',null,array('id'=>'','class'=>'text-input required')) !!}</li> 
                <li class="form-row text-area-row"><label>Категорія</label> {!! Form::select('id_category', $category) !!}</li> 
                <li class="form-row text-area-row"><label>Опис</label>{!! Form::textarea('content',null,array('id'=>'','class'=>'text-area required')) !!}</li> 
                <li class="form-row text-input-row"><label>Відео</label>{!! Form::text('video',null,array('id'=>'','class'=>'text-input required')) !!} </li> 
                <li class="form-row text-input-row"><label>Зображення</label>{!! Form::file('image', null) !!} </li> 
                <li class="button-row">{!! Form::submit('Редагувати', array('class' => 'btn-submit')) !!}  </li>
            </ol>
        </fieldset>
    {!! Form::close() !!}
</div>


</div>
<div class="clear"></div>




@endsection