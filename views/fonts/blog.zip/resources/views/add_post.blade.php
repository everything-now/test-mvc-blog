@extends('layouts.app')

@section('content')

<div class="content box">

    <h1 class="title">Додати фільм</h1>
<div class="form-container">
    {!! Form::open(array(
                        'url'=> action('PostController@store'),
                        'method'=>'POST',
                        'accept-charset'=>'UTF-8',
                        'class'=>'forms',
                        'files'=>true,
                        )) !!} 
        <fieldset>
            <ol>
                <li class="form-row text-input-row"><label>Назва</label>{!! Form::text('title','',array('id'=>'','class'=>'text-input required')) !!}</li> 
                <li class="form-row text-area-row"><label>Категорія</label> {!! Form::select('id_category', $category, array('id'=>'soflow')) !!}</li> 
                <li class="form-row text-area-row"><label>Опис</label>{!! Form::textarea('content','',array('id'=>'','class'=>'text-area required')) !!}</li> 
                <li class="form-row text-input-row"><label>Відео</label>{!! Form::text('video','',array('id'=>'','class'=>'text-input required')) !!} </li> 
                <li class="form-row text-input-row"><label>Зображення</label>{!! Form::file('image', null) !!} </li> 
                <li class="button-row">{!! Form::submit('Додати', array('class' => 'btn-submit')) !!}  </li>
            </ol>
        </fieldset>
    {!! Form::close() !!}
</div>

</div>
<div class="clear"></div>

@endsection

