@extends('layouts.app')

@section('content')

<div class="box">

    <h1 class="title">{{ $post->title }} </h1>       
    
    <div class="one-third">
      
      <div class="outer none"><span class="inset"><img width="290 px" src="{{ $post->image }}"/></span></div>
      Додано: {{ $post->created_at }}<br> <!-- Оновлено: {{ $post->updated_at }} --><br>

      Рейтинг IMDB:<b> {{ $rating->movie['imdbRating']  }}/10</b><br>
      Всього голосів: {{ $rating->movie['imdbVotes'] }}<br><br>

      Рейтинг за версією сайту
      <div id="rating">
        <input type="hidden" name="val" value="{{ $votes }}">
        <input type="hidden" name="votes" value="{{ $count_votes }}">
      </div>
      @if (Auth::guest() == false)
      <input type="hidden" name="_token" value="{{ csrf_token() }}">
      <input type="hidden" name="id_user" value="{{ Auth::user()->id }}">
      <input type="hidden" name="id_post" value="{{ $post->id }}">
      @endif
    </div>
    <script type="text/javascript">
    $('#rating').rating({
      fx: 'full',
      image: '/images/votes/stars.png',
      loader: '/images/votes/ajax-loader.gif',
      url: '{{URL::action('VoteController@store')}}',
      @if (Auth::guest() || Auth::user()->id == $validate) readOnly: true, @endif
       callback: function(responce){
           this.vote_success.fadeOut(2000);
       }
        });
    </script>

    <div class="two-third last">
    @can('create') <div align="right"><a href="{{$post->id}}/edit">Редагувати</a></div> @endcan
      <h4>Про фільм</h4>
        {{$post->content}}

      <h4>Відео</h4>
        {!! $post->video !!}   
    <br><br>

    <div id="comments">
              
      <h3 id="comments-title"> @if ($count_comments == 0) Ще ніхто не залишив відгук @else Всього коментарів: {{$count_comments}} @endif</h3>
      @foreach($comments as $comment)
          <ol id="singlecomments" class="commentlist">
          <li class="comment">
        <div class="comment">
          <div class="comment-author vcard user frame">
            <img alt="" src='/images/movie.jpg' class='avatar avatar-70 photo' height='70' width='70' />
          </div>
          <div class="message">

            <div class="info">
              <h2>{{$comment->user}}</h2>
              <span class="meta"> {{$comment->created_at}}</span>
            </div>
            <div class="comment-body ">
              <p>{{$comment->content}}</p>
            </div>
            <span class="edit-link"></span>
          </div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
      </li></ol>
      @endforeach
    </div>

    <div class="clear"></div>
          <div id="comment-form" class="comment-form">
          @if (Auth::guest())
              Щоб залишити коментар <a href="{{ url('/login') }}">авторизуйтесь</a> або <a href="{{ url('/register') }}">пройдіть реєстрацію</a>               
          @else
          @include('comment')
          @endif
          </div>
</div>

</div>

<br>

@endsection('content')
