<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBookorders extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bookorders', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title');
            $table->string('title_original');
            $table->integer('year');
            $table->string('image');
            $table->string('wish');
            $table->string('orderer');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('bookorders');
    }
}
