<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bookorders extends Model
{
    protected $fillable = [
		'title',
		'title_original',
		'image',
		'year',
		'wish',
		'orderer',
		'status'
	];
}
