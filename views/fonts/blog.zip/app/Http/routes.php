<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {

	Route::get('/', 'HomeController@getHome');

	Route::resource('allposts', 'PostController');

	Route::auth();

	// Route::get('add_post', [function () {
	//     return view('add_post');
	// }]);

	Route::get('add_post', 'PostController@category');

	Route::post('add_post', ['PostController@store']);

	Route::post('add_post', ['PostController@store']);

	Route::get('category/{id}', 'PostController@categoryid');

	Route::post('allposts/{id}','CommentsController@save');
	
	Route::post('vote', 'VoteController@store');
	//Route::post('vote', ['middleware' => 'vote', 'VoteController@store']);

	Route::resource('bookorders', 'BookOrdersController',
		['only' => ['index', 'store']]);
	


});



