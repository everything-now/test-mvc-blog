<?php

namespace App\Http\Middleware;

use Closure;
use App\Vote;

class VoteMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Auth::guest() == true){
            $votes = "Щоб проголосувати ви повинні бути авторизовані"  
            return $votes;
        }
        elseif(Vote::where('id_post', '=', Request::input('id_post'))->where('id_user', '=', Auth::user()->id)->pluck('id_user')->first() == true ){
            
            $votes = "Ви вже голосували за цю статтю!"
            dd($votes);
            return $votes;
            
        }else{

            return $next($request);

        }


    }
}
