<?php

namespace App\Http\Controllers;

use Request;
use App\Bookorders;
use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class BookOrdersController extends Controller
{
    public function index()
    {
    	$bookorders = BookOrders::all();



    //dd($bookorders);
    	return view('bookorders', compact('bookorders'));
    }

    public function store()
    {
    	$all = Request::only('title', 'wish');
    	$from_imdb = json_decode(Request::input('from_imdb'));

    	$all['title_original'] = $from_imdb->title;

    	$all['image'] = $from_imdb->poster;

    	$all['year'] = $from_imdb->year;

    	$all['status'] = 'Очікує';

    	if (Auth::guest()){

    		$all['orderer'] = Request::ip();

    	}
    	else{

    		$all['orderer'] = Auth::user()->name;

    	}

    	Bookorders::create($all);

    	return back()->with('message','Дякуємо, ваш запит буде розглянуто найближчим часом'); 
    }

}
