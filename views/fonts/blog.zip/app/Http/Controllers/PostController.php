<?php

namespace App\Http\Controllers;

use App\Post;
use App\Vote;
use App\Category;
use Request;
use App\Comment;
use Illuminate\Support\Facades\Auth;

use App\Http\Requests\CreatePost;

use App\Http\Controllers\Controller;

class PostController extends Controller
{

	public function show($id)
	{
		//$this->authorize('show');
		$count_votes = Vote::where('id_post', '=', $id)->count('votes');
		
		$votes = Vote::where('id_post', '=', $id)->sum('votes');

		if(Auth::guest() == false){
			$validate = Vote::where('id_post', '=', $id)->where('id_user', '=', Auth::user()->id)->pluck('id_user')->first();
		}

		//dd($validate);

		if($count_votes == 0){
			$votes = "Ще ніхто не проголосував";
		}

		else{
			$votes = $votes/$count_votes;
			$votes = round($votes, 1, PHP_ROUND_HALF_UP);
		}

		//$votes = $votes / count($votes);
    	//dd($votes);

        //return view('allposts', compact('votes'));

		$post = Post::findOrFail($id);
		$title = $post->title;
		$rating = simplexml_load_file("http://www.omdbapi.com/?t=".$title."&y=&plot=short&r=xml");
		
		$comments=Comment::where('id_post', '=', $id)->get();
		$count_comments=Comment::where('id_post', '=', $id)->count();

		return view('show', compact('post', 'comments', 'count_comments', 'rating', 'votes', 'count_votes', 'validate'));
	}
	    

	public function store(CreatePost $request)
	{
		if(Request::hasFile('image')){

			$all = Request::except(['image']);
			$file = Request::file('image');
			$imgname = $file->getClientOriginalName();
			$file->move('images', $imgname);
			$all['image']="/images/".$imgname;
			
		}

        $this->authorize('create');
		Post::create($all);
		return redirect('/');
	}

	public function edit($id)
	{
        $this->authorize('create');
		$post = Post::findOrFail($id);
    	$category = Category::lists('title', 'id');
		return view('edit', compact('post', 'category'));
	}

	public function update($id, CreatePost $request)
	{
		if(Request::hasFile('image')){

			$all = Request::except(['image']);
			$file = Request::file('image');
			$imgname = $file->getClientOriginalName();
			$file->move('images', $imgname);
			$all['image']="/images/".$imgname;
			
		}
        $this->authorize('create');
		$post = Post::findOrFail($id);
		$post->update($all);
		return redirect('/');		
	}

	public function category() {

    	$category = Category::lists('title', 'id');

		return view('add_post', compact('category'));
    }

    public function categoryid($id) {

		$allposts = Post::where('id_category', '=', $id)->get();
		$category = Category::where('id', '=', $id)->pluck('title')->first();
		//dd($category);

        return view('allposts', compact('allposts', 'category'));
    }

    public function showvotes ($id) {


    }



}
