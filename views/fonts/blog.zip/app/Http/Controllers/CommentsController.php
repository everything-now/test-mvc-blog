<?php

namespace App\Http\Controllers;

use App\Post;
use App\Comments;
use Request;
use App\Comment;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CommentsController extends Controller
{
    public function save($id)
	{
		$all=Request::all();
		$all['id_post'] = $id;
		//dd($all);
		Comment::create($all);

		return back()->with('message','Коментар успішно доданий'); 
	}

	// public function show()
	// {
	// 	$comments=Comment::all();
	// 	return view('show', compact('comments'));
	// }
}
