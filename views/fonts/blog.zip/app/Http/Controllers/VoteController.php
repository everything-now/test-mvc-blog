<?php

namespace App\Http\Controllers;

use Request;
use App\Vote;
use Response;
use Requests;

use App\Http\Controllers\Controller;

class VoteController extends Controller
{
    public function store() {
		
    	$all = Request::all();
    	$all['votes'] = $all['score'];
    	unset($all['val'], $all['vote-id'], $all['score']);
       	
       	Vote::create($all);

		return Response::json(["status" => "OK", "msg" => "Ваш голос врахований"]); 
        
    }

}
