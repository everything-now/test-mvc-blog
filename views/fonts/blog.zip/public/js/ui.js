function formatRepo (repo) {
  if (repo.loading) return repo.text;
  
  var markup = "<img width='54' height='80' src='"+ repo.posters.thumbnail +"'> <span>" + repo.title + "</span> <span><b>(" + repo.year + ")</b></span>";
  return markup;
}

function formatRepoSelection (repo) {
  return repo.title || repo.text || repo.posters.thumbnail;
}

$(".js-data-example-ajax").select2({
  ajax: {
    url: "http://api.rottentomatoes.com/api/public/v1.0/movies.json?apikey=ny97sdcpqetasj8a4v2na8va",
    dataType: 'jsonp',
    delay: 250,
    data: function (params) {
      return {
        q: params.term, // search term
        page: params.page
      };
    },
    processResults: function (data, params) {
      params.page = params.page || 1;     
 
      return {
        results: data.movies,
        pagination: {
          more: (params.page * 30) < data.total_count
        }
      };
    },
    cache: true
  },
  escapeMarkup: function (markup) { return markup; }, 
  minimumInputLength: 1,
  templateResult: formatRepo,
  templateSelection: formatRepoSelection 
});
$('.js-data-example-ajax').on('change', function() {
  var data = $(this).select2('data')[0];
  var film = new Object();
  film.title = data.title;
  film.poster = data.posters.thumbnail;
  film.year = data.year;
  $(this).find('option:last-child').attr('value', JSON.stringify(film));   
});

